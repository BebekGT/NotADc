import os
import re
import json
import utils
import colorama

logger = utils.Logger(format="horizontal")

class OG_Ascii:
    def __init__(self):
        self.version = "5.3"
        colorama.init(autoreset=False)
        self.bot_name = "Null"
        self.guild_name = "Null"
        self.options = []
        self.colors = [
            (148, 0, 255),
            (148, 0, 255),
            (148, 0, 255),
            (170, 0, 255),
            (191, 0, 255),
            (212, 0, 255),
            (233, 0, 255),
            (255, 0, 255),
            (255, 0, 233),
            (255, 0, 212),
            (255, 0, 191),
            (255, 0, 170),
            (255, 0, 148),
            (255, 0, 148),
            (255, 0, 148),
            (255, 0, 148),
            (255, 0, 148),
        ]


    def init(self):
        pass
    def center(self, text):
        lines = text.split('\n')
        width = os.get_terminal_size().columns
        min_len = min(len(line) for line in lines)
        pad = (width - min_len) // 2
        cl = [line.center(min_len + 2 * pad) for line in lines]
        cl = [line.center(width) for line in cl]

        return '\n'.join(cl)


    @staticmethod
    def create(options, per_row=5):
        title_len = 30
        menu = []

        menu.append(f"╔{'╦'.join(['═' * title_len] * per_row)}╗")
        menu.append("")
        for i, opt in enumerate(options):
            if i % per_row == 0 and i != 0:
                menu[-1] += "║"
                menu.append(f"╠{'╬'.join(['═' * title_len] * per_row)}╣")
                menu.append("")

            padded_opt = f"[{str(i + 1).zfill(2)}] {opt.ljust(title_len - 7)}"
            if i % per_row == 0:
                menu[-1] += f"║ {padded_opt} "
            else:
                menu[-1] += f"║ {padded_opt} "

        remaining_slots = per_row - (len(options) % per_row)
        if remaining_slots != per_row:
            menu[-1] += f"║{' ' * title_len}" * remaining_slots + "║"

        menu.append(f"╚{'╩'.join(['═' * title_len] * per_row)}╝")
        return '\n'.join(menu)


    @staticmethod
    def rgb(r, g, b, background=False):
        return f"\033[38;2;{r};{g};{b}m"

    def grad(self, ascii, thing):
        if thing:
            lnn = ascii.split('\n')
            for i, line in enumerate(lnn):
                if line == "" or line == None:
                    i -= 1
                    continue

                if i < len([
            (148, 0, 255),
            (170, 0, 255),
            (191, 0, 255),
            (200, 0, 255),
            (212, 0, 255),
            (233, 0, 255),
            (255, 0, 255),
            (255, 0, 233),
            (255, 0, 212),
            (255, 0, 191),
            (255, 0, 170),
            (255, 0, 148),
            (255, 0, 148),
            (255, 0, 148),
            (255, 0, 148),
            (255, 0, 148),
        ]):
                    r, g, b = self.colors[i]
                    clr = self.rgb(r, g, b)
                    print(f"{clr}{line}\033[0m")
                else:
                    print(line)


        else:
            lnn = ascii.split('\n')
            for i, line in enumerate(lnn):
                if line == "" or line == None:
                    i -= 1
                    continue

                if i < len(self.colors):
                    r, g, b = self.colors[i]
                    clr = self.rgb(r, g, b)
                    print(f"{clr}{line}\033[0m")
                else:
                    print(line)



    def run(self, login=True):
        os.system('cls')
        print("\n")

        if login == True:
            ascii = """
                                 ▒▒▒          ░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒      ▒░▒▒▒      ▒▒▒                                 ▒░░░▒
                               ▒▒██▒         ▒▒▒▒▒░▒███████████████████░▒▒▒▒▒▒▒████▒     ▒▒▒█▒       ▒▒▒     ▒▒     ▒ ▒      ▒████▒
                             ▒█████▒        ▒████▒   ▒▒▒▒▒█████▒▒       ▒▒░▒▒▒▒████▒    ▒████▒    ░▒▒░░▒   ▒░█▒   ▒░▒░▒      ▒████▒
                            ▒█████▒        ▒▒████▒      ░▒████▒▒      ▒░███▒▒▒█████▒   ▒▒████▒   ▒████▒   ▒██▒▒  ▒▒███▒▒    ▒████▒▒
                           ▒▒████▒         ▒████▒▒      ▒████░▒      ▒░████▒▒▒████▒    ▒████▒▒   ▒███▒  ▒▒███▒   ▒█████▒ ▒▒█████▒▒
                          ░▒████▒          ▒████▒      ▒▒████▒   ▒▒▒░█████▒▒▒████▒▒    ▒████▒  ▒▒███▒▒  ▒████▒   ▒█████▒▒██████▒▒
                          ▒░████▒         ░▒███▒       ▒███░▒   ▒▒▒░████████████▒▒▒▒  ▒▒███▒   ▒████▒  ▒█████▒  ▒░████████████▒▒
                          ▒████▒          ▒▒███▒      ▒░███▒▒      ▒████▒▒▒▒████▒▒▒   ▒▒██░▒   ▒███▒  ▒▒████▒   ▒███▒▒███▒▒███▒
                       ▒▒▒█████▒▒░░░▒░█░▒▒▒███▒       ▒▒██▒▒      ░▒███▒  ▒███▒▒      ▒███▒    ▒███▒ ▒▒████▒   ▒▒███▒▒▒█▒░▒██▒▒
                      ░ ░▒█████████████░▒▒▒██▒▒       ▒███▒       ▒███▒▒  ▒███▒       ▒██▒▒    ▒░█████████▒▒   ▒██▒▒▒░▒▒▒▒▒█▒▒
                        ▒▒▒░░▒▒▒▒▒▒       ▒░▒▒        ▒░██▒       ▒██░▒   ▒██▒░       ▒░▒░       ▒░█████░▒     ▒█▒       ▒░▒▒
                                         ▒░▒          ▒▒█▒        ▒█▒▒   ▒░▒▒        ▒▒▒                                 ▒▒▒
                                                      ▒░▒▒       ▒▒▒     ▒▒░
                                                      ▒▒▒
"""
            thing = self.center(f"""(INFO):
  VER - {self.version}
  DSC - .gg/pop
  Made By - @realestneonic

""")
        else:
            ascii = """
                                                           ▒▒▒          ░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒      ▒░▒▒▒      ▒▒▒                                 ▒░░░▒
                                                         ▒▒██▒         ▒▒▒▒▒░▒███████████████████░▒▒▒▒▒▒▒████▒     ▒▒▒█▒       ▒▒▒     ▒▒     ▒ ▒      ▒████▒
                                                       ▒█████▒        ▒████▒   ▒▒▒▒▒█████▒▒       ▒▒░▒▒▒▒████▒    ▒████▒    ░▒▒░░▒   ▒░█▒   ▒░▒░▒      ▒████▒
                                                      ▒█████▒        ▒▒████▒      ░▒████▒▒      ▒░███▒▒▒█████▒   ▒▒████▒   ▒████▒   ▒██▒▒  ▒▒███▒▒    ▒████▒▒
                                                     ▒▒████▒         ▒████▒▒      ▒████░▒      ▒░████▒▒▒████▒    ▒████▒▒   ▒███▒  ▒▒███▒   ▒█████▒ ▒▒█████▒▒
                                                    ░▒████▒          ▒████▒      ▒▒████▒   ▒▒▒░█████▒▒▒████▒▒    ▒████▒  ▒▒███▒▒  ▒████▒   ▒█████▒▒██████▒▒
                                                    ▒░████▒         ░▒███▒       ▒███░▒   ▒▒▒░████████████▒▒▒▒  ▒▒███▒   ▒████▒  ▒█████▒  ▒░████████████▒▒
                                                    ▒████▒          ▒▒███▒      ▒░███▒▒      ▒████▒▒▒▒████▒▒▒   ▒▒██░▒   ▒███▒  ▒▒████▒   ▒███▒▒███▒▒███▒
                                                 ▒▒▒█████▒▒░░░▒░█░▒▒▒███▒       ▒▒██▒▒      ░▒███▒  ▒███▒▒      ▒███▒    ▒███▒ ▒▒████▒   ▒▒███▒▒▒█▒░▒██▒▒
                                                ░ ░▒█████████████░▒▒▒██▒▒       ▒███▒       ▒███▒▒  ▒███▒       ▒██▒▒    ▒░█████████▒▒   ▒██▒▒▒░▒▒▒▒▒█▒▒
                                                  ▒▒▒░░▒▒▒▒▒▒       ▒░▒▒        ▒░██▒       ▒██░▒   ▒██▒░       ▒░▒░       ▒░█████░▒     ▒█▒       ▒░▒▒
                                                                   ▒░▒          ▒▒█▒        ▒█▒▒   ▒░▒▒        ▒▒▒                                 ▒▒▒
                                                                                ▒░▒▒       ▒▒▒     ▒▒░
                                                                                ▒▒▒"""
            result = self.center(self.create(self.options, 5))
            bot_name = self.bot_name[:10].ljust(10)
            guild_name = self.guild_name[:10].rjust(10)

            thing = result
            thing += self.center(f"""
╔════════════════════════════════════════╗                                                                        ╔════════════════════════════════════════╗
║ Bot -                    {bot_name}    ║                                                                        ║    {guild_name}                - Guild   ║
╚════════════════════════════════════════╝                                                                        ╚════════════════════════════════════════╝
                    """)
        self.grad(ascii, False)
        self.grad(thing, True)

    def ChangeTheme(self):
        logger.err("Can not change theme in OG version, please change it to normal version to change theme.")
